# Kadr — Instagram uslubidagi Telegram Mini App

## GitHub'ga yuklash

1. github.com'da yangi repository yarating (masalan: `kadr-app`), **Public** qilib qoldiring
2. Ushbu papkadagi barcha fayllarni o'sha repositoryga yuklang:
   - GitHub sayti orqali: repo ichida "Add file" → "Upload files" → papkadagi hamma fayl va papkalarni tashlang
   - yoki terminal orqali:
     ```
     git init
     git add .
     git commit -m "Kadr ilovasi"
     git branch -M main
     git remote add origin https://github.com/FOYDALANUVCHI_NOMI/kadr-app.git
     git push -u origin main
     ```

## Vercel bilan internetga chiqarish

1. vercel.com ga GitHub hisobingiz bilan kiring
2. "Add New Project" → GitHub repongizni tanlang (`kadr-app`)
3. Framework sifatida **Vite** avtomatik tanilib qoladi — hech narsa o'zgartirmasdan "Deploy" bosing
4. 1 daqiqada tayyor bo'ladi, sizga shunday manzil beriladi:
   `https://kadr-app-xxxxx.vercel.app`

## Telegram botga ulash

1. Telegramda **@BotFather** ga yozing
2. `/newbot` — bot yarating, tokenni saqlab qo'ying
3. `/newapp` — botingizni tanlang, Vercel'dan olgan HTTPS manzilni kiriting
4. Botga kirib, "Ochish" tugmasini bosing — ilova to'g'ridan-to'g'ri Telegram ichida ochiladi

## Mahalliy ishga tushirish (ixtiyoriy)

```
npm install
npm run dev
```
